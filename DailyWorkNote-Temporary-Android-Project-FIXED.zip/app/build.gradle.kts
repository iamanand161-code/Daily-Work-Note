kotlin {
    jvmToolchain(17)
}

plugins { id("com.android.application"); kotlin("android") }
android {
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

 namespace="com.dailyworknote"; compileSdk=35
 defaultConfig { applicationId="com.dailyworknote"; minSdk=23; targetSdk=35; versionCode=1; versionName="0.1.0" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.appcompat:appcompat:1.7.0")
}