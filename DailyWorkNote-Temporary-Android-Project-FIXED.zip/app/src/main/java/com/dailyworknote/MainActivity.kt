package com.dailyworknote
import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
class MainActivity: Activity() {
 private lateinit var w: WebView
 @SuppressLint("SetJavaScriptEnabled") override fun onCreate(b: Bundle?) {
  super.onCreate(b); w=WebView(this)
  w.settings.javaScriptEnabled=true; w.settings.domStorageEnabled=true
  w.settings.allowFileAccess=true; w.webChromeClient=WebChromeClient()
  w.loadUrl("file:///android_asset/daily-work-note.html"); setContentView(w)
 }
 override fun onBackPressed(){if(w.canGoBack())w.goBack() else super.onBackPressed()}
}